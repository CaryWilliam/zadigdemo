def square(x):
    return x * x

def test_the_square_of_negative_5_is_negative_25():
    assert square(-5) == -25
