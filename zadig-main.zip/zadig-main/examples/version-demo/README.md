## Zadig 中的构建变量透传 Demo
### Build

```
$ make default

build the version
build done.

$ ./build/version.linux

Version(hard code): 0.1
```
### Version output

```
$ ./build/version.linux version

Version: 
GitBranch:
CommitId:
PR:
Build Date: 
Go Version: 
OS/Arch: 
Build URL: 
```
