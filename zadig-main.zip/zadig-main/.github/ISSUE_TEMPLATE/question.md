---
name: Ask a Question
about: I want to ask a question.
title: "[Question]"
labels: question
assignees: jamsman94

---

## General Question

<!--

Before asking a question, make sure you have:

- Googled your question.
- Searched open and closed [GitHub issues](https://github.com/koderover/zadig/issues?utf8=%E2%9C%93&q=is%3Aissue)

-->
